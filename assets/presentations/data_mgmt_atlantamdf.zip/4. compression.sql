-- run query before compression

SET STATISTICS IO ON;

SELECT SalesAmount, OrderDateKey
FROM Fact.InternetSales
WHERE ProductKey=217;

-- then run it after
ALTER TABLE Fact.InternetSales
	REBUILD WITH (DATA_COMPRESSION = PAGE)
;

