
CREATE PARTITION FUNCTION PFDaily(INT)
AS RANGE RIGHT
FOR VALUES (
20080101,20080102,20080103,20080104,20080105,20080106,20080107,20080108,20080109,20080110,20080111,20080112,20080113,20080114,20080115,20080116,20080117,20080118,20080119,20080120,20080121,20080122,20080123,20080124,20080125,20080126,20080127,20080128,20080129,20080130,20080131,
20080201,20080202,20080203,20080204,20080205,20080206,20080207,20080208,20080209,20080210,20080211,20080212,20080213,20080214,20080215,20080216,20080217,20080218,20080219,20080220,20080221,20080222,20080223,20080224,20080225,20080226,20080227,20080228,20080229,
20080301,20080302,20080303,20080304,20080305,20080306,20080307,20080308,20080309,20080310,20080311,20080312,20080313,20080314,20080315,20080316,20080317,20080318,20080319,20080320,20080321,20080322,20080323,20080324,20080325,20080326,20080327,20080328,20080329,20080330,20080331,
20080401,20080402,20080403,20080404,20080405,20080406,20080407,20080408,20080409,20080410,20080411,20080412,20080413,20080414,20080415,20080416,20080417,20080418,20080419,20080420,20080421,20080422,20080423,20080424,20080425,20080426,20080427,20080428,20080429,20080430,
20080501,20080502,20080503,20080504,20080505,20080506,20080507,20080508,20080509,20080510,20080511,20080512,20080513,20080514,20080515,20080516,20080517,20080518,20080519,20080520,20080521,20080522,20080523,20080524,20080525,20080526,20080527,20080528,20080529,20080530,20080531,
20080601,20080602,20080603,20080604,20080605,20080606,20080607,20080608,20080609,20080610,20080611,20080612,20080613,20080614,20080615,20080616,20080617,20080618,20080619,20080620,20080621,20080622,20080623,20080624,20080625,20080626,20080627,20080628,20080629,20080630,
20080701,20080702,20080703,20080704,20080705,20080706,20080707,20080708,20080709,20080710,20080711,20080712,20080713,20080714,20080715,20080716,20080717,20080718,20080719,20080720,20080721,20080722,20080723,20080724,20080725,20080726,20080727,20080728,20080729,20080730, 20080731
);

CREATE PARTITION SCHEME PSDaily
AS PARTITION PFDaily
ALL TO ([Primary]);

-- create heap
SELECT *
INTO Fact.InternetSales2008
FROM dbo.FactInternetSales
WHERE OrderDateKey BETWEEN '20080101' AND '20080731';

ALTER TABLE Fact.InternetSales2008
	ADD CONSTRAINT pk_FactInternetSales2008 PRIMARY KEY CLUSTERED (OrderDateKey, SalesOrderNumber, SalesOrderLineNumber)
	ON PSDaily(OrderDateKey)
;

-- let's view the partitions
SELECT i.name AS indexname, i.type_desc AS indextype, p.partition_id, p.partition_number, p.data_compression_desc, p.rows
FROM sys.indexes i
	JOIN sys.partitions p ON p.object_id = i.object_id AND p.index_id = i.index_id
WHERE name = N'pk_FactInternetSales2008'
ORDER BY indexname, p.partition_number;



-- now lets simulate loading August 1, 2008 data (using August 1, 2007 data and changing the dates)
IF OBJECT_ID('Staging.[20080801]') IS NOT NULL
	DROP TABLE Staging.[20080801]
;
CREATE TABLE Staging.[20080801]
(
	ProductKey int NOT NULL,
	OrderDateKey int NOT NULL CONSTRAINT cnt_20080801 CHECK (OrderDateKey = 20080801), -- constraint MUST match target partition boundary
	DueDateKey int NOT NULL,
	ShipDateKey int NOT NULL,
	CustomerKey int NOT NULL,
	PromotionKey int NOT NULL,
	CurrencyKey int NOT NULL,
	SalesTerritoryKey int NOT NULL,
	SalesOrderNumber nvarchar(20) NOT NULL,
	SalesOrderLineNumber tinyint NOT NULL,
	RevisionNumber tinyint NOT NULL,
	OrderQuantity smallint NOT NULL,
	UnitPrice money NOT NULL,
	ExtendedAmount money NOT NULL,
	UnitPriceDiscountPct float NOT NULL,
	DiscountAmount float NOT NULL,
	ProductStandardCost money NOT NULL,
	TotalProductCost money NOT NULL,
	SalesAmount money NOT NULL,
	TaxAmt money NOT NULL,
	Freight money NOT NULL,
	CarrierTrackingNumber nvarchar(25) NULL,
	CustomerPONumber nvarchar(25) NULL,
	OrderDate datetime NULL,
	DueDate datetime NULL,
	ShipDate datetime NULL,
	CONSTRAINT pk_staging20080801 PRIMARY KEY CLUSTERED (OrderDateKey, SalesOrderNumber, SalesOrderLineNumber) 
);


-- insert 1 day into staging
INSERT INTO Staging.[20080801] WITH (TABLOCK)
        (ProductKey
        ,OrderDateKey
        ,DueDateKey
        ,ShipDateKey
        ,CustomerKey
        ,PromotionKey
        ,CurrencyKey
        ,SalesTerritoryKey
        ,SalesOrderNumber
        ,SalesOrderLineNumber
        ,RevisionNumber
        ,OrderQuantity
        ,UnitPrice
        ,ExtendedAmount
        ,UnitPriceDiscountPct
        ,DiscountAmount
        ,ProductStandardCost
        ,TotalProductCost
        ,SalesAmount
        ,TaxAmt
        ,Freight
        ,CarrierTrackingNumber
        ,CustomerPONumber
        ,OrderDate
        ,DueDate
        ,ShipDate)
SELECT  ProductKey
       ,OrderDateKey + 10000 AS OrderDateKey
       ,DueDateKey + 10000 AS DueDateKey
       ,ShipDateKey + 10000 AS ShipDateKey
       ,CustomerKey
       ,PromotionKey
       ,CurrencyKey
       ,SalesTerritoryKey
       ,SalesOrderNumber
       ,SalesOrderLineNumber
       ,RevisionNumber
       ,OrderQuantity
       ,UnitPrice
       ,ExtendedAmount
       ,UnitPriceDiscountPct
       ,DiscountAmount
       ,ProductStandardCost
       ,TotalProductCost
       ,SalesAmount
       ,TaxAmt
       ,Freight
       ,CarrierTrackingNumber
       ,CustomerPONumber
       ,DATEADD(year, 1, OrderDate) AS OrderDate
       ,DueDate
       ,ShipDate
FROM dbo.FactInternetSales
WHERE OrderDateKey = 20070801; -- grab same day last year and update the dates


-- compare row counts before and after switch
-- target table
SELECT COUNT(*) AS [Fact.InternetSales2008]
FROM Fact.InternetSales2008
WHERE OrderDateKey=20080801;

-- staging table
SELECT COUNT(*) AS [Staging.20080801]
FROM Staging.[20080801];




-- split the partition function
ALTER PARTITION FUNCTION PFDaily()
	SPLIT RANGE (20080801)
;

/* If you create all the partitions in the same filegroup, that filegroup is initially assigned to be the NEXT USED filegroup automatically. 
   However, after a split operation is performed, there is no longer a designated NEXT USED filegroup. You must explicitly assign the filegroup 
   to be the NEXT USED filegroup by using ALTER PARITION SCHEME or a subsequent split operation will fail.*/
ALTER PARTITION SCHEME PSDaily
	NEXT USED [PRIMARY]
;

-- switch partition from staging to Fact table
-- only requires a Sch-M lock 
ALTER TABLE Staging.[20080801]
	SWITCH TO Fact.InternetSales2008 PARTITION $PARTITION.PFDaily(20080801)
;

-- let's view the partitions
SELECT i.name AS indexname, i.type_desc AS indextype, p.partition_id, p.partition_number, p.data_compression_desc, p.rows
FROM sys.indexes i
	JOIN sys.partitions p ON p.object_id = i.object_id AND p.index_id = i.index_id
WHERE name = N'pk_FactInternetSales2008'
ORDER BY indexname, p.partition_number;



-- SWITCH OUT DEMO *********************************************************************************************************************
-- same concept in reverse
-- use until they introduce a "truncate table partition #" DDL stmt
-- see script "3a. partition switching"


