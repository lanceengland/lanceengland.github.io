USE AdventureWorksDW2012;

-- drop views
IF OBJECT_ID('Fact.vwProductTotalsByDay') IS NOT NULL
	DROP VIEW Fact.vwProductTotalsByDay
;
IF OBJECT_ID('Fact.vwInternetSales') IS NOT NULL
	DROP VIEW Fact.vwInternetSales
; 
-- drop tables
IF OBJECT_ID('Fact.InternetSales') IS NOT NULL
	DROP TABLE Fact.InternetSales
;
IF OBJECT_ID('Fact.InternetSales_CS') IS NOT NULL
	DROP TABLE Fact.InternetSales_CS
;
IF OBJECT_ID('Fact.InternetSales2008') IS NOT NULL
	DROP TABLE Fact.InternetSales2008
;
IF OBJECT_ID('Staging.[20080801]') IS NOT NULL
	DROP TABLE Staging.[20080801]
;
IF OBJECT_ID('Staging.[20080101]') IS NOT NULL
	DROP TABLE Staging.[20080101]
;
IF OBJECT_ID('Dim.Date') IS NOT NULL
	DROP TABLE Dim.Date
;
IF OBJECT_ID('Mart.InternetSales2001') IS NOT NULL DROP TABLE Mart.InternetSales2001;
IF OBJECT_ID('Mart.InternetSales2002') IS NOT NULL DROP TABLE Mart.InternetSales2002;
IF OBJECT_ID('Mart.InternetSales2003') IS NOT NULL DROP TABLE Mart.InternetSales2003;
IF OBJECT_ID('Mart.InternetSales2004') IS NOT NULL DROP TABLE Mart.InternetSales2004;
IF OBJECT_ID('Mart.InternetSales2005') IS NOT NULL DROP TABLE Mart.InternetSales2005;
IF OBJECT_ID('Mart.InternetSales2006') IS NOT NULL DROP TABLE Mart.InternetSales2006;
IF OBJECT_ID('Mart.InternetSales2007') IS NOT NULL DROP TABLE Mart.InternetSales2007;
IF OBJECT_ID('Mart.InternetSales2008') IS NOT NULL DROP TABLE Mart.InternetSales2008;
IF OBJECT_ID('Mart.InternetSales2009') IS NOT NULL DROP TABLE Mart.InternetSales2009;
IF OBJECT_ID('Mart.InternetSales2010') IS NOT NULL DROP TABLE Mart.InternetSales2010;
IF OBJECT_ID('Mart.InternetSales2011') IS NOT NULL DROP TABLE Mart.InternetSales2011;
IF OBJECT_ID('Mart.InternetSales2012') IS NOT NULL DROP TABLE Mart.InternetSales2012;
IF OBJECT_ID('Mart.InternetSales2013') IS NOT NULL DROP TABLE Mart.InternetSales2013;

-- drop partition scheme
IF EXISTS (SELECT * FROM sys.partition_schemes WHERE name = N'PSYearly')
	EXEC('DROP PARTITION SCHEME PSYearly')
;
IF EXISTS (SELECT * FROM sys.partition_schemes WHERE name = N'PSYearlyArchive')
	EXEC('DROP PARTITION SCHEME PSYearlyArchive')
;
IF EXISTS (SELECT * FROM sys.partition_schemes WHERE name = N'PSDaily')
	EXEC('DROP PARTITION SCHEME PSDaily')
;
-- drop partition function
IF EXISTS (SELECT * FROM sys.partition_functions WHERE name = N'PFYearly')
	EXEC('DROP PARTITION FUNCTION PFYearly')
;
IF EXISTS (SELECT * FROM sys.partition_functions WHERE name = N'PFYearlyArchive')
	EXEC('DROP PARTITION FUNCTION PFYearlyArchive')
;
IF EXISTS (SELECT * FROM sys.partition_functions WHERE name = N'PFDaily')
	EXEC('DROP PARTITION FUNCTION PFDaily')
;

-- drop schemas
IF EXISTS (SELECT * FROM sys.schemas WHERE name = N'Dim') 
	EXEC('DROP SCHEMA Dim;')
;
IF EXISTS (SELECT * FROM sys.schemas WHERE name = N'Fact') 
	EXEC('DROP SCHEMA Fact;')
;
IF EXISTS (SELECT * FROM sys.schemas WHERE name = N'Mart') 
	EXEC('DROP SCHEMA Mart;')
;
IF EXISTS (SELECT * FROM sys.schemas WHERE name = N'Staging') 
	EXEC('DROP SCHEMA Staging;')
;

-- drop filtered index
IF EXISTS (SELECT * FROM sys.indexes WHERE name = 'idx_DimProduct_current')
	DROP INDEX dbo.DimProduct.idx_DimProduct_current
;
GO

-- delete files and filegroups
USE [master];
IF EXISTS (SELECT * FROM sys.master_files mf JOIN sys.databases d ON d.database_id = mf.database_id WHERE d.name = N'AdventureWorksDW2012' AND mf.name = N'Fact')
	ALTER DATABASE [AdventureWorksDW2012] REMOVE FILE Fact
;
IF EXISTS(SELECT * FROM sys.master_files mf JOIN sys.databases d ON d.database_id = mf.database_id WHERE d.name = N'AdventureWorksDW2012' AND mf.name = N'Archive')
	ALTER DATABASE [AdventureWorksDW2012] REMOVE FILE Archive
;
GO
USE AdventureWorksDW2012;
IF EXISTS(SELECT * FROM sys.filegroups WHERE name = N'FastFG')
	ALTER DATABASE [AdventureWorksDW2012] REMOVE FILEGROUP FastFG
;
IF EXISTS(SELECT * FROM sys.filegroups WHERE name = N'SlowFG')
	ALTER DATABASE [AdventureWorksDW2012] REMOVE FILEGROUP SlowFG
;
