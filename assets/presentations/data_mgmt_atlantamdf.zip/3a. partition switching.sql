USE AdventureWorksDW2012;

-- let's drop the partition for Jan 1, 2008
IF OBJECT_ID('Staging.[20080101]') IS NOT NULL
	DROP TABLE Staging.[20080101]
;
CREATE TABLE Staging.[20080101]
(
	ProductKey int NOT NULL,
	OrderDateKey int NOT NULL, 
	DueDateKey int NOT NULL,
	ShipDateKey int NOT NULL,
	CustomerKey int NOT NULL,
	PromotionKey int NOT NULL,
	CurrencyKey int NOT NULL,
	SalesTerritoryKey int NOT NULL,
	SalesOrderNumber nvarchar(20) NOT NULL,
	SalesOrderLineNumber tinyint NOT NULL,
	RevisionNumber tinyint NOT NULL,
	OrderQuantity smallint NOT NULL,
	UnitPrice money NOT NULL,
	ExtendedAmount money NOT NULL,
	UnitPriceDiscountPct float NOT NULL,
	DiscountAmount float NOT NULL,
	ProductStandardCost money NOT NULL,
	TotalProductCost money NOT NULL,
	SalesAmount money NOT NULL,
	TaxAmt money NOT NULL,
	Freight money NOT NULL,
	CarrierTrackingNumber nvarchar(25) NULL,
	CustomerPONumber nvarchar(25) NULL,
	OrderDate datetime NULL,
	DueDate datetime NULL,
	ShipDate datetime NULL,
	CONSTRAINT pk_staging20080101 PRIMARY KEY CLUSTERED (OrderDateKey, SalesOrderNumber, SalesOrderLineNumber) 
);

-- compare row counts before and after switch
SELECT COUNT(*) AS [Fact.InternetSales2008]
FROM Fact.InternetSales2008
WHERE OrderDateKey = 20080101;

SELECT COUNT(*) AS [Staging.20080101]
FROM Staging.[20080101];


ALTER TABLE Fact.InternetSales2008
	SWITCH PARTITION $PARTITION.PFDaily(20080101) TO Staging.[20080101] 
;
ALTER PARTITION FUNCTION PFDaily()
	MERGE RANGE (20080101)
;
ALTER PARTITION SCHEME PSDaily
	NEXT USED [PRIMARY]
;