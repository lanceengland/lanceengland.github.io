USE AdventureWorksDW2012;

-- create schemas
IF NOT EXISTS (SELECT * FROM sys.schemas WHERE name = N'Dim') 
	EXEC('CREATE SCHEMA Dim AUTHORIZATION dbo;')
;
IF NOT EXISTS (SELECT * FROM sys.schemas WHERE name = N'Fact') 
	EXEC('CREATE SCHEMA Fact AUTHORIZATION dbo;')
;
IF NOT EXISTS (SELECT * FROM sys.schemas WHERE name = N'Mart') 
	EXEC('CREATE SCHEMA Mart AUTHORIZATION dbo;')
;
IF NOT EXISTS (SELECT * FROM sys.schemas WHERE name = N'Staging') 
	EXEC('CREATE SCHEMA Staging AUTHORIZATION dbo;')
;
GO

---------------------------------------------------------------------------------
-- create helper function (B/oogle Itzik Ben-Gan numbers function)
IF OBJECT_ID('dbo.GetNums') IS NOT NULL
	DROP FUNCTION dbo.GetNums
;
GO
CREATE FUNCTION [dbo].[GetNums](@n AS BIGINT) RETURNS TABLE
AS
RETURN
WITH
L0   AS(SELECT 1 AS c UNION ALL SELECT 1),
L1   AS(SELECT 1 AS c FROM L0 AS A CROSS JOIN L0 AS B),
L2   AS(SELECT 1 AS c FROM L1 AS A CROSS JOIN L1 AS B),
L3   AS(SELECT 1 AS c FROM L2 AS A CROSS JOIN L2 AS B),
L4   AS(SELECT 1 AS c FROM L3 AS A CROSS JOIN L3 AS B),
L5   AS(SELECT 1 AS c FROM L4 AS A CROSS JOIN L4 AS B),
Nums AS(SELECT ROW_NUMBER() OVER(ORDER BY (SELECT NULL)) AS n FROM L5)
SELECT TOP (@n) n FROM Nums ORDER BY n;
GO

---------------------------------------------------------------------------------
-- delete references to fact table
IF OBJECT_ID('Fact.vwProductTotalsByDay') IS NOT NULL
	DROP VIEW Fact.vwProductTotalsByDay
;

-- create & populate fact table
IF OBJECT_ID('Fact.InternetSales') IS NOT NULL
	DROP TABLE Fact.InternetSales
;

-- CREATE heap
SELECT *
INTO Fact.InternetSales
FROM dbo.FactInternetSales;


-- generate more data for fact table (copy 2008 data into 2001-2004 and 2009-2013)
WITH
cte_2008 AS
(
	SELECT *
	FROM dbo.FactInternetSales
	WHERE OrderDate >= '20080101' AND OrderDate < '20090101'
)
INSERT INTO Fact.InternetSales WITH (TABLOCK)
        (ProductKey
        ,OrderDateKey
        ,DueDateKey
        ,ShipDateKey
        ,CustomerKey
        ,PromotionKey
        ,CurrencyKey
        ,SalesTerritoryKey
        ,SalesOrderNumber
        ,SalesOrderLineNumber
        ,RevisionNumber
        ,OrderQuantity
        ,UnitPrice
        ,ExtendedAmount
        ,UnitPriceDiscountPct
        ,DiscountAmount
        ,ProductStandardCost
        ,TotalProductCost
        ,SalesAmount
        ,TaxAmt
        ,Freight
        ,CarrierTrackingNumber
        ,CustomerPONumber
        ,OrderDate
        ,DueDate
        ,ShipDate)
SELECT  ProductKey

	   ,CAST(CONVERT(VARCHAR(8), DATEADD(YEAR, t.n, OrderDate), 112) AS INT) AS OrderDate
       ,CAST(CONVERT(VARCHAR(8), DATEADD(YEAR, t.n, DueDate), 112) AS INT) AS DueDateKey
       ,CAST(CONVERT(VARCHAR(8), DATEADD(YEAR, t.n, ShipDate), 112) AS INT) AS ShipDateKey

       ,CustomerKey
       ,PromotionKey
       ,CurrencyKey
       ,SalesTerritoryKey
       ,CONVERT(VARCHAR(8), DATEADD(YEAR, t.n, OrderDate), 112) + SalesOrderNumber AS SalesOrderNumber
       ,SalesOrderLineNumber
       ,RevisionNumber
       ,OrderQuantity
       ,UnitPrice
       ,ExtendedAmount
       ,UnitPriceDiscountPct
       ,DiscountAmount
       ,ProductStandardCost
       ,TotalProductCost
       ,SalesAmount
       ,TaxAmt
       ,Freight
       ,CarrierTrackingNumber
       ,CustomerPONumber

	   ,DATEADD(YEAR, t.n, OrderDate) AS OrderDate
       ,DATEADD(YEAR, t.n, DueDate) AS DueDate
       ,DATEADD(YEAR, t.n, ShipDate) AS ShipDate
FROM cte_2008 CROSS JOIN 
	 (VALUES (-7), (-6), (-5), (-4), (1), (2), (3), (4), (5)) t(n)
;


---------------------------------------------------------------------------------
-- create & populate Dim date table
IF OBJECT_ID('Dim.Date') IS NOT NULL
	DROP TABLE Dim.Date
;
SELECT *
INTO Dim.Date
FROM dbo.DimDate;

ALTER TABLE Dim.Date
	ADD CONSTRAINT PK_DimDate PRIMARY KEY CLUSTERED (DateKey)
;
CREATE UNIQUE NONCLUSTERED INDEX idx_DimDate_fulldate ON Dim.Date (FullDateAlternateKey);


-- add dates 2011 - 2015
WITH    
cte_NewDates
AS 
(
    SELECT   CAST(CONVERT(VARCHAR(8),DATEADD(DAY,T.n,D.FullDateAlternateKey),112) AS INT) AS DateKey
            ,DATEADD(DAY,T.n,D.FullDateAlternateKey) AS FullDateAlternateKey
            ,DATEPART(dw,DATEADD(DAY,T.n,D.FullDateAlternateKey)) AS DayNumberOfWeek
            ,DAY(DATEADD(DAY,T.n,D.FullDateAlternateKey)) AS DayNumberOfMonth
            ,DATEPART(dy, DATEADD(DAY,T.n,D.FullDateAlternateKey)) AS DayNumberOfYear
			,DATEPART(ww, DATEADD(DAY,T.n,D.FullDateAlternateKey)) AS WeekNumberOfYear
			,DATENAME(MONTH, DATEADD(DAY,T.n,D.FullDateAlternateKey)) AS EnglishMonthName
			,DATENAME(dw, DATEADD(DAY,T.n,D.FullDateAlternateKey)) AS EnglishDayNameOfWeek
            ,MONTH(DATEADD(DAY,T.n,D.FullDateAlternateKey)) AS MonthNumberOfYear
            ,DATEPART(q, DATEADD(DAY,T.n,D.FullDateAlternateKey)) AS CalendarQuarter
            ,YEAR(DATEADD(DAY,T.n,D.FullDateAlternateKey)) AS CalendarYear
    FROM      (
                SELECT FullDateAlternateKey
                FROM   dbo.DimDate
                WHERE  FullDateAlternateKey = '20101231'
            ) D
    CROSS JOIN (
                SELECT    n
                FROM      dbo.GetNums(1500)
                ) T
)
INSERT  INTO Dim.Date

        (DateKey
        ,FullDateAlternateKey
        ,DayNumberOfWeek

        ,EnglishDayNameOfWeek
        ,SpanishDayNameOfWeek
        ,FrenchDayNameOfWeek

        ,DayNumberOfMonth
        ,DayNumberOfYear
        ,WeekNumberOfYear

        ,EnglishMonthName
        ,SpanishMonthName
        ,FrenchMonthName

        ,MonthNumberOfYear
        ,CalendarQuarter
        ,CalendarYear

        ,CalendarSemester
        ,FiscalQuarter
        ,FiscalYear
        ,FiscalSemester)

        SELECT  DateKey
                ,FullDateAlternateKey
                ,DayNumberOfWeek

				,EnglishDayNameOfWeek
				,''
				,''

                ,DayNumberOfMonth
                ,DayNumberOfYear
				,WeekNumberOfYear

                ,EnglishMonthName
				,''
				,''

				,MonthNumberOfYear
                ,CalendarQuarter
                ,CalendarYear

				,0
				,0
				,0
				,0
        FROM    cte_NewDates
;

-- Remember! Get path for data files on Don's machine
/*
SELECT   mf.name
		,mf.physical_name
FROM sys.master_files mf JOIN
	sys.databases d ON d.database_id = mf.database_id
WHERE d.name = N'AdventureWorksDW2012';
*/
------------------------------------------------------------------

--USE [master];
--ALTER DATABASE [AdventureWorksDW2012] ADD FILEGROUP FastFG;
--ALTER DATABASE [AdventureWorksDW2012] ADD FILEGROUP SlowFG;
--GO
--ALTER DATABASE [AdventureWorksDW2012] ADD FILE ( NAME = Fact, FILENAME = 'D:\SQLData\Fact.ndf') TO FILEGROUP FastFG;
--ALTER DATABASE [AdventureWorksDW2012] ADD FILE ( NAME = Archive, FILENAME = 'D:\SQLData\Archive.ndf') TO FILEGROUP SlowFG;
--GO