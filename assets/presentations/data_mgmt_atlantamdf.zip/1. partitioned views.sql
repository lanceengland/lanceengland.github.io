-- create tables for years 2001 - 2013
IF OBJECT_ID('Mart.InternetSales2001') IS NOT NULL DROP TABLE Mart.InternetSales2001;
IF OBJECT_ID('Mart.InternetSales2002') IS NOT NULL DROP TABLE Mart.InternetSales2002;
IF OBJECT_ID('Mart.InternetSales2003') IS NOT NULL DROP TABLE Mart.InternetSales2003;
IF OBJECT_ID('Mart.InternetSales2004') IS NOT NULL DROP TABLE Mart.InternetSales2004;
IF OBJECT_ID('Mart.InternetSales2005') IS NOT NULL DROP TABLE Mart.InternetSales2005;
IF OBJECT_ID('Mart.InternetSales2006') IS NOT NULL DROP TABLE Mart.InternetSales2006;
IF OBJECT_ID('Mart.InternetSales2007') IS NOT NULL DROP TABLE Mart.InternetSales2007;
IF OBJECT_ID('Mart.InternetSales2008') IS NOT NULL DROP TABLE Mart.InternetSales2008;
IF OBJECT_ID('Mart.InternetSales2009') IS NOT NULL DROP TABLE Mart.InternetSales2009;
IF OBJECT_ID('Mart.InternetSales2010') IS NOT NULL DROP TABLE Mart.InternetSales2010;
IF OBJECT_ID('Mart.InternetSales2011') IS NOT NULL DROP TABLE Mart.InternetSales2011;
IF OBJECT_ID('Mart.InternetSales2012') IS NOT NULL DROP TABLE Mart.InternetSales2012;
IF OBJECT_ID('Mart.InternetSales2013') IS NOT NULL DROP TABLE Mart.InternetSales2013;

-- create heap tables
SELECT * INTO Mart.InternetSales2001 FROM Fact.InternetSales WHERE OrderDateKey BETWEEN 20010101 AND 20011231;
SELECT * INTO Mart.InternetSales2002 FROM Fact.InternetSales WHERE OrderDateKey BETWEEN 20020101 AND 20021231;
SELECT * INTO Mart.InternetSales2003 FROM Fact.InternetSales WHERE OrderDateKey BETWEEN 20030101 AND 20031231;
SELECT * INTO Mart.InternetSales2004 FROM Fact.InternetSales WHERE OrderDateKey BETWEEN 20040101 AND 20041231;
SELECT * INTO Mart.InternetSales2005 FROM Fact.InternetSales WHERE OrderDateKey BETWEEN 20050101 AND 20051231;
SELECT * INTO Mart.InternetSales2006 FROM Fact.InternetSales WHERE OrderDateKey BETWEEN 20060101 AND 20061231;
SELECT * INTO Mart.InternetSales2007 FROM Fact.InternetSales WHERE OrderDateKey BETWEEN 20070101 AND 20071231;
SELECT * INTO Mart.InternetSales2008 FROM Fact.InternetSales WHERE OrderDateKey BETWEEN 20080101 AND 20081231;
SELECT * INTO Mart.InternetSales2009 FROM Fact.InternetSales WHERE OrderDateKey BETWEEN 20090101 AND 20091231;
SELECT * INTO Mart.InternetSales2010 FROM Fact.InternetSales WHERE OrderDateKey BETWEEN 20100101 AND 20101231;
SELECT * INTO Mart.InternetSales2011 FROM Fact.InternetSales WHERE OrderDateKey BETWEEN 20110101 AND 20111231;
SELECT * INTO Mart.InternetSales2012 FROM Fact.InternetSales WHERE OrderDateKey BETWEEN 20120101 AND 20121231;
SELECT * INTO Mart.InternetSales2013 FROM Fact.InternetSales WHERE OrderDateKey BETWEEN 20130101 AND 20131231;

-- add optional clustering key
CREATE UNIQUE CLUSTERED INDEX idx_clus_mart2001 ON Mart.InternetSales2001(OrderDateKey, SalesOrderNumber, SalesOrderLineNumber);
CREATE UNIQUE CLUSTERED INDEX idx_clus_mart2002 ON Mart.InternetSales2002(OrderDateKey, SalesOrderNumber, SalesOrderLineNumber);
CREATE UNIQUE CLUSTERED INDEX idx_clus_mart2003 ON Mart.InternetSales2003(OrderDateKey, SalesOrderNumber, SalesOrderLineNumber);
CREATE UNIQUE CLUSTERED INDEX idx_clus_mart2004 ON Mart.InternetSales2004(OrderDateKey, SalesOrderNumber, SalesOrderLineNumber);
CREATE UNIQUE CLUSTERED INDEX idx_clus_mart2005 ON Mart.InternetSales2005(OrderDateKey, SalesOrderNumber, SalesOrderLineNumber);
CREATE UNIQUE CLUSTERED INDEX idx_clus_mart2006 ON Mart.InternetSales2006(OrderDateKey, SalesOrderNumber, SalesOrderLineNumber);
CREATE UNIQUE CLUSTERED INDEX idx_clus_mart2007 ON Mart.InternetSales2007(OrderDateKey, SalesOrderNumber, SalesOrderLineNumber);
CREATE UNIQUE CLUSTERED INDEX idx_clus_mart2008 ON Mart.InternetSales2008(OrderDateKey, SalesOrderNumber, SalesOrderLineNumber);
CREATE UNIQUE CLUSTERED INDEX idx_clus_mart2009 ON Mart.InternetSales2009(OrderDateKey, SalesOrderNumber, SalesOrderLineNumber);
CREATE UNIQUE CLUSTERED INDEX idx_clus_mart2010 ON Mart.InternetSales2010(OrderDateKey, SalesOrderNumber, SalesOrderLineNumber);
CREATE UNIQUE CLUSTERED INDEX idx_clus_mart2011 ON Mart.InternetSales2011(OrderDateKey, SalesOrderNumber, SalesOrderLineNumber);
CREATE UNIQUE CLUSTERED INDEX idx_clus_mart2012 ON Mart.InternetSales2012(OrderDateKey, SalesOrderNumber, SalesOrderLineNumber);
CREATE UNIQUE CLUSTERED INDEX idx_clus_mart2013 ON Mart.InternetSales2013(OrderDateKey, SalesOrderNumber, SalesOrderLineNumber);


-- "stitch" tables together. union all is better than union here
IF OBJECT_ID('Fact.vwInternetSales') IS NOT NULL
	DROP VIEW Fact.vwInternetSales
; 
GO
CREATE VIEW Fact.vwInternetSales AS 
	SELECT * FROM mart.InternetSales2001 UNION ALL
	SELECT * FROM mart.InternetSales2002 UNION ALL
	SELECT * FROM mart.InternetSales2003 UNION ALL
	SELECT * FROM mart.InternetSales2004 UNION ALL
	SELECT * FROM mart.InternetSales2005 UNION ALL
	SELECT * FROM mart.InternetSales2006 UNION ALL
	SELECT * FROM mart.InternetSales2007 UNION ALL
	SELECT * FROM mart.InternetSales2008 UNION ALL
	SELECT * FROM mart.InternetSales2009 UNION ALL
	SELECT * FROM mart.InternetSales2010 UNION ALL
	SELECT * FROM mart.InternetSales2011 UNION ALL
	SELECT * FROM mart.InternetSales2012 UNION ALL
	SELECT * FROM mart.InternetSales2013
;


-- the view can perform partition elimination, but only after CHECK constraints added (display execution plan)
SELECT ProductKey, SUM(SalesAmount) AS Total
FROM Fact.vwInternetSales
WHERE OrderDateKey BETWEEN 20010101 AND 20030131
GROUP BY ProductKey;


-- add check constraints
ALTER TABLE Mart.InternetSales2001 WITH CHECK ADD CONSTRAINT ct_2001 CHECK(OrderDateKey BETWEEN 20010101 AND 20011231);
ALTER TABLE Mart.InternetSales2002 WITH CHECK ADD CONSTRAINT ct_2002 CHECK(OrderDateKey BETWEEN 20020101 AND 20021231);
ALTER TABLE Mart.InternetSales2003 WITH CHECK ADD CONSTRAINT ct_2003 CHECK(OrderDateKey BETWEEN 20030101 AND 20031231);
ALTER TABLE Mart.InternetSales2004 WITH CHECK ADD CONSTRAINT ct_2004 CHECK(OrderDateKey BETWEEN 20040101 AND 20041231);
ALTER TABLE Mart.InternetSales2005 WITH CHECK ADD CONSTRAINT ct_2005 CHECK(OrderDateKey BETWEEN 20050101 AND 20051231);
ALTER TABLE Mart.InternetSales2006 WITH CHECK ADD CONSTRAINT ct_2006 CHECK(OrderDateKey BETWEEN 20060101 AND 20061231);
ALTER TABLE Mart.InternetSales2007 WITH CHECK ADD CONSTRAINT ct_2007 CHECK(OrderDateKey BETWEEN 20070101 AND 20071231);
ALTER TABLE Mart.InternetSales2008 WITH CHECK ADD CONSTRAINT ct_2008 CHECK(OrderDateKey BETWEEN 20080101 AND 20081231);
ALTER TABLE Mart.InternetSales2009 WITH CHECK ADD CONSTRAINT ct_2009 CHECK(OrderDateKey BETWEEN 20090101 AND 20091231);
ALTER TABLE Mart.InternetSales2010 WITH CHECK ADD CONSTRAINT ct_2010 CHECK(OrderDateKey BETWEEN 20100101 AND 20101231);
ALTER TABLE Mart.InternetSales2011 WITH CHECK ADD CONSTRAINT ct_2011 CHECK(OrderDateKey BETWEEN 20110101 AND 20111231);
ALTER TABLE Mart.InternetSales2012 WITH CHECK ADD CONSTRAINT ct_2012 CHECK(OrderDateKey BETWEEN 20120101 AND 20121231);
ALTER TABLE Mart.InternetSales2013 WITH CHECK ADD CONSTRAINT ct_2013 CHECK(OrderDateKey BETWEEN 20130101 AND 20131231);