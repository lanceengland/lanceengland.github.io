-- filtered index

set statistics io on;

-- look, these products have version history
SELECT ProductAlternateKey, COUNT(*) AS c
FROM dbo.DimProduct
GROUP BY ProductAlternateKey
HAVING COUNT(*) > 1
ORDER BY c DESC;

-- lets look at a single product (all versions)
SELECT ProductKey, ProductAlternateKey, ProductSubcategoryKey, EnglishProductName, ListPrice,  StartDate, EndDate, Status
FROM dbo.DimProduct 
WHERE ProductAlternateKey = 'CA-1098';

-- all current versions of products
SELECT ProductKey, ProductAlternateKey, ProductSubcategoryKey, EnglishProductName, ListPrice,  StartDate, EndDate, Status
FROM dbo.DimProduct
WHERE Status = 'Current';


IF EXISTS (SELECT * FROM sys.indexes WHERE name = 'idx_DimProduct_current')
	DROP INDEX dbo.DimProduct.idx_DimProduct_current
;
CREATE UNIQUE NONCLUSTERED INDEX idx_DimProduct_current 
ON dbo.DimProduct (ProductKey) INCLUDE (ProductAlternateKey, ProductSubcategoryKey, EnglishProductName, ListPrice,  StartDate, EndDate, Status)
WHERE Status = 'Current';


-- compress filtered indexes? sure!
ALTER INDEX idx_DimProduct_current 
ON dbo.DimProduct 
REBUILD PARTITION = ALL WITH (DATA_COMPRESSION = PAGE);

-- now re-run query for all current versions of products