-- notes: largest fact table  3,699,666,393  total rows, 11,342,210 per day
USE AdventureWorksDW2012;

-- function creates boundaries (left|right indicates which side boundary values should be included)
CREATE PARTITION FUNCTION PFYearly(INT)
AS RANGE RIGHT
FOR VALUES (	20010101				
			   ,20020101
			   ,20030101
			   ,20040101
			   ,20050101
			   ,20060101
			   ,20070101

			   ,20080101
			   ,20090101
			   ,20100101
			   ,20110101
			   ,20120101
			   ,20130101
			   ,20140101
);

-- schema maps partitions to physical locations
-- usually each partition to a seperate filegroup
CREATE PARTITION SCHEME PSYearly
AS PARTITION PFYearly
ALL TO ([Primary]);


-- add clustering PK (partitioning column needs to be included)
-- Note: We are creating on a partition scheme NOT a filegroup
ALTER TABLE Fact.InternetSales
	ADD CONSTRAINT pk_FactInternetSales PRIMARY KEY CLUSTERED (OrderDateKey, SalesOrderNumber, SalesOrderLineNumber)
	ON PSYearly(OrderDateKey)  
;

-- let's view our handywork
SELECT i.name AS indexname, i.type_desc AS indextype, p.partition_id, p.partition_number, p.data_compression_desc, p.rows
FROM sys.indexes i
	JOIN sys.partitions p ON p.object_id = i.object_id AND p.index_id = i.index_id
WHERE name = N'pk_FactInternetSales'
ORDER BY indexname, p.partition_number;

-- system functions to inspect row detail
SELECT $PARTITION.PFYearly(OrderDateKey) AS [PARTITION #]
	   ,OrderDateKey, SalesOrderNumber, SalesOrderLineNumber
FROM Fact.InternetSales;

-- same thing, in aggregate
SELECT $PARTITION.PFYearly(OrderDateKey) AS [PARTITION #]
	   ,COUNT(*) AS RowCt
	   ,MIN(OrderDateKey) AS LowerBound
	   ,MAX(OrderDateKey) AS UpperBound
FROM Fact.InternetSales f
GROUP BY $PARTITION.PFYearly(OrderDateKey)
ORDER BY [PARTITION #];


-- execute with query plan on to observe partition elimination (Note: actual partition count and partitions accessed)
SELECT *
FROM Fact.InternetSales
WHERE OrderDateKey = 20100201 OR OrderDateKey = 20110201