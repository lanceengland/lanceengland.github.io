USE AdventureWorksDW2012;

IF OBJECT_ID('Fact.InternetSales_CS') IS NOT NULL
	DROP TABLE Fact.InternetSales_CS
;

-- build a heap
SELECT *
INTO Fact.InternetSales_CS
FROM Fact.InternetSales

-- add clustering key
ALTER TABLE Fact.InternetSales_CS
	ADD CONSTRAINT PK_FactInternetSales_CS PRIMARY KEY CLUSTERED (OrderDateKey, SalesOrderNumber, SalesOrderLineNumber) -- must include partitioning key in PK to enforce uniqueness across partitions
	ON PSYearly(OrderDateKey)
;


-- add columnstore index
CREATE COLUMNSTORE INDEX csidx_FactInternetSales 
	ON Fact.InternetSales_CS(ProductKey, OrderDateKey, DueDateKey, ShipDateKey, CustomerKey, PromotionKey, CurrencyKey, 
		SalesTerritoryKey, SalesOrderNumber, SalesOrderLineNumber, RevisionNumber, OrderQuantity, UnitPrice, ExtendedAmount, 
		UnitPriceDiscountPct, DiscountAmount, ProductStandardCost, TotalProductCost, SalesAmount, TaxAmt, Freight, CarrierTrackingNumber, 
		CustomerPONumber, OrderDate, DueDate, ShipDate)
	ON PSYearly(OrderDateKey)
;



SET STATISTICS IO ON;
-- query #1 using regular Fact table
SELECT  ps.EnglishProductSubcategoryName
       ,SUM(CASE WHEN d.MonthNumberOfYear = 1 THEN fis.SalesAmount END) AS JanSales
	   ,SUM(CASE WHEN d.MonthNumberOfYear = 2 THEN fis.SalesAmount END) AS FebSales
	   ,SUM(CASE WHEN d.MonthNumberOfYear = 3 THEN fis.SalesAmount END) AS MarSales
	   ,SUM(CASE WHEN d.MonthNumberOfYear = 4 THEN fis.SalesAmount END) AS AprSales
	   ,SUM(CASE WHEN d.MonthNumberOfYear = 5 THEN fis.SalesAmount END) AS MaySales
	   ,SUM(CASE WHEN d.MonthNumberOfYear = 6 THEN fis.SalesAmount END) AS JunSales
	   ,SUM(CASE WHEN d.MonthNumberOfYear = 7 THEN fis.SalesAmount END) AS JulSales
	   ,SUM(CASE WHEN d.MonthNumberOfYear = 8 THEN fis.SalesAmount END) AS AugSales
	   ,SUM(CASE WHEN d.MonthNumberOfYear = 9 THEN fis.SalesAmount END) AS SepSales
	   ,SUM(CASE WHEN d.MonthNumberOfYear = 10 THEN fis.SalesAmount END) AS OctSales
	   ,SUM(CASE WHEN d.MonthNumberOfYear = 11 THEN fis.SalesAmount END) AS NovSales
	   ,SUM(CASE WHEN d.MonthNumberOfYear = 12 THEN fis.SalesAmount END) AS DecSales
	   ,SUM(fis.SalesAmount) AS TotalSales
FROM    Fact.InternetSales fis
JOIN    dbo.DimProduct dp
        ON dp.ProductKey = fis.ProductKey
JOIN    dbo.DimProductSubcategory ps
        ON ps.ProductSubcategoryKey = dp.ProductSubcategoryKey
JOIN Dim.Date d ON d.DateKey = fis.OrderDateKey
GROUP BY ps.EnglishProductSubcategoryName;

-- query #2 using Fact w/ columnstore index
SELECT  ps.EnglishProductSubcategoryName
       ,SUM(CASE WHEN d.MonthNumberOfYear = 1 THEN fis.SalesAmount END) AS JanSales
	   ,SUM(CASE WHEN d.MonthNumberOfYear = 2 THEN fis.SalesAmount END) AS FebSales
	   ,SUM(CASE WHEN d.MonthNumberOfYear = 3 THEN fis.SalesAmount END) AS MarSales
	   ,SUM(CASE WHEN d.MonthNumberOfYear = 4 THEN fis.SalesAmount END) AS AprSales
	   ,SUM(CASE WHEN d.MonthNumberOfYear = 5 THEN fis.SalesAmount END) AS MaySales
	   ,SUM(CASE WHEN d.MonthNumberOfYear = 6 THEN fis.SalesAmount END) AS JunSales
	   ,SUM(CASE WHEN d.MonthNumberOfYear = 7 THEN fis.SalesAmount END) AS JulSales
	   ,SUM(CASE WHEN d.MonthNumberOfYear = 8 THEN fis.SalesAmount END) AS AugSales
	   ,SUM(CASE WHEN d.MonthNumberOfYear = 9 THEN fis.SalesAmount END) AS SepSales
	   ,SUM(CASE WHEN d.MonthNumberOfYear = 10 THEN fis.SalesAmount END) AS OctSales
	   ,SUM(CASE WHEN d.MonthNumberOfYear = 11 THEN fis.SalesAmount END) AS NovSales
	   ,SUM(CASE WHEN d.MonthNumberOfYear = 12 THEN fis.SalesAmount END) AS DecSales
	   ,SUM(fis.SalesAmount) AS TotalSales
FROM    Fact.InternetSales_CS fis
JOIN    dbo.DimProduct dp
        ON dp.ProductKey = fis.ProductKey
JOIN    dbo.DimProductSubcategory ps
        ON ps.ProductSubcategoryKey = dp.ProductSubcategoryKey
JOIN Dim.Date d ON d.DateKey = fis.OrderDateKey
GROUP BY ps.EnglishProductSubcategoryName
;


